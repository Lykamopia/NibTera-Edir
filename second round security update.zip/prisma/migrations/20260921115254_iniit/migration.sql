-- CreateEnum
CREATE TYPE "EdirStatus" AS ENUM ('PENDING', 'ACTIVE', 'SUSPENDED', 'CLOSED');

-- CreateEnum
CREATE TYPE "RoleScope" AS ENUM ('SUPER_ADMIN', 'PLATFORM', 'HEAD_OFFICE', 'DISTRICT', 'BRANCH', 'EDIR');

-- CreateEnum
CREATE TYPE "MemberStatus" AS ENUM ('ACTIVE', 'INACTIVE', 'SUSPENDED', 'TERMINATED');

-- CreateEnum
CREATE TYPE "DocumentStatus" AS ENUM ('DRAFT', 'PENDING', 'APPROVED', 'REJECTED');

-- CreateEnum
CREATE TYPE "PaymentStatusValue" AS ENUM ('PAID', 'PENDING');

-- CreateEnum
CREATE TYPE "InstallmentPlanType" AS ENUM ('REGISTRATION', 'CONTRIBUTION');

-- CreateEnum
CREATE TYPE "InstallmentStatus" AS ENUM ('PENDING', 'PAID');

-- CreateEnum
CREATE TYPE "PaymentLogStatus" AS ENUM ('PENDING', 'SUCCESS', 'PARTIAL', 'FAILED', 'VOID');

-- CreateEnum
CREATE TYPE "ApprovalModule" AS ENUM ('MANUAL_PAYMENT', 'EMERGENCY_CLAIM', 'EMERGENCY_DISBURSEMENT', 'ASSET_ISSUANCE', 'ASSET_RETURN', 'MEMBER_REMOVAL', 'MEMBER_STATUS_CHANGE', 'PAYMENT_VOID', 'RULE_CHANGE', 'PENALTY_WAIVER', 'EDIR_REGISTRATION', 'EDIR_UPDATE', 'USER_CREATION', 'DOCUMENT_ACTION', 'RELATIVE_DOCUMENT_ACTION', 'RELATIONSHIP_CATEGORY');

-- CreateEnum
CREATE TYPE "DmsDocStatus" AS ENUM ('DRAFT', 'PENDING', 'APPROVED', 'REJECTED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "ApprovalStatus" AS ENUM ('DRAFT', 'PENDING', 'APPROVED', 'REJECTED', 'RETURNED', 'CLOSED');

-- CreateEnum
CREATE TYPE "ApprovalEventType" AS ENUM ('SUBMITTED', 'COMMENTED', 'APPROVED', 'EXECUTED', 'REJECTED', 'RETURNED', 'RESUBMITTED');

-- CreateEnum
CREATE TYPE "RulesVersionStatus" AS ENUM ('DRAFT', 'APPROVED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "MemberRequestType" AS ENUM ('RELATIVE', 'EMERGENCY', 'ASSET', 'GRIEVANCE', 'FEEDBACK');

-- CreateEnum
CREATE TYPE "MemberRequestStatus" AS ENUM ('PENDING', 'IN_REVIEW', 'APPROVED', 'REJECTED', 'RESOLVED');

-- CreateEnum
CREATE TYPE "EmergencyStatus" AS ENUM ('REPORTED', 'PENDING', 'ACTIVE', 'RESOLVED', 'REJECTED');

-- CreateEnum
CREATE TYPE "EventStatus" AS ENUM ('SCHEDULED', 'COMPLETED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "ParticipantStatus" AS ENUM ('INVITED', 'ATTENDING', 'DECLINED', 'PRESENT', 'ABSENT', 'EXCUSED');

-- CreateEnum
CREATE TYPE "AssetIssuanceStatus" AS ENUM ('REQUESTED', 'APPROVED', 'ISSUED', 'RETURNED', 'COMPENSATION_PENDING', 'CLOSED');

-- CreateTable
CREATE TABLE "Edir" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "logoUrl" TEXT,
    "branchId" TEXT,
    "status" "EdirStatus" NOT NULL DEFAULT 'ACTIVE',
    "accountNumber" TEXT,
    "address" TEXT,
    "contactPersonName" TEXT,
    "contactAddress" TEXT,
    "contactMobile" TEXT,
    "contactEmail" TEXT,
    "agreementDocUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Edir_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "District" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "code" TEXT,
    "description" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "District_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Branch" (
    "id" TEXT NOT NULL,
    "districtId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "code" TEXT,
    "description" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Branch_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "name" TEXT,
    "email" TEXT,
    "phone" TEXT,
    "title" TEXT,
    "emailVerified" TIMESTAMP(3),
    "avatar" TEXT,
    "hashedPassword" TEXT,
    "status" TEXT NOT NULL DEFAULT 'INVITED',
    "mustChangePassword" BOOLEAN NOT NULL DEFAULT false,
    "onboardingCompleted" BOOLEAN NOT NULL DEFAULT false,
    "tokenVersion" INTEGER NOT NULL DEFAULT 0,
    "failedLoginAttempts" INTEGER NOT NULL DEFAULT 0,
    "lockoutUntil" TIMESTAMP(3),
    "lastLoginAt" TIMESTAMP(3),
    "passwordChangedAt" TIMESTAMP(3),
    "passwordResetCount" INTEGER NOT NULL DEFAULT 0,
    "lastPasswordResetAt" TIMESTAMP(3),
    "lastIp" TEXT,
    "lastUserAgent" TEXT,
    "twoFactorEnabled" BOOLEAN NOT NULL DEFAULT false,
    "twoFactorSecret" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "roleId" TEXT,
    "edirId" TEXT,
    "branchId" TEXT,
    "districtId" TEXT,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Role" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "permissions" TEXT NOT NULL DEFAULT '',
    "scope" "RoleScope" NOT NULL DEFAULT 'EDIR',
    "edirId" TEXT,
    "districtId" TEXT,
    "branchId" TEXT,

    CONSTRAINT "Role_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Member" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "userId" TEXT,
    "name" TEXT NOT NULL,
    "occupation" TEXT,
    "photoUrl" TEXT,
    "dateOfBirth" TIMESTAMP(3),
    "gender" TEXT,
    "nationalId" TEXT,
    "phone" TEXT,
    "email" TEXT,
    "address" TEXT,
    "city" TEXT,
    "subcity" TEXT,
    "woreda" TEXT,
    "emergencyContactName" TEXT,
    "emergencyContactPhone" TEXT,
    "role" TEXT NOT NULL DEFAULT 'Member',
    "status" "MemberStatus" NOT NULL DEFAULT 'ACTIVE',
    "joinDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "registrationInstallmentCount" INTEGER NOT NULL DEFAULT 1,
    "firstContributionAtJoin" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Member_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Relative" (
    "id" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "relationship" TEXT NOT NULL,
    "phone" TEXT,
    "dateOfBirth" TIMESTAMP(3),
    "isBeneficiary" BOOLEAN NOT NULL DEFAULT false,
    "benefitShare" INTEGER,
    "isDependent" BOOLEAN NOT NULL DEFAULT false,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Relative_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RelativeDocument" (
    "id" TEXT NOT NULL,
    "relativeId" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'General',
    "documentName" TEXT,
    "fileUrl" TEXT NOT NULL,
    "fileName" TEXT,
    "fileType" TEXT NOT NULL DEFAULT 'file',
    "status" "DocumentStatus" NOT NULL DEFAULT 'PENDING',
    "remarks" TEXT,
    "notes" TEXT,
    "version" INTEGER NOT NULL DEFAULT 1,
    "supersedesId" TEXT,
    "pendingAction" TEXT,
    "pendingPayload" JSONB,
    "rejectionReason" TEXT,
    "uploadedById" TEXT,
    "reviewedById" TEXT,
    "approvedById" TEXT,
    "reviewedAt" TIMESTAMP(3),
    "approvedAt" TIMESTAMP(3),
    "archivedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "RelativeDocument_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MemberDocument" (
    "id" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "fileUrl" TEXT NOT NULL,
    "fileName" TEXT,
    "status" "DocumentStatus" NOT NULL DEFAULT 'PENDING',
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "MemberDocument_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RelationshipCategory" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "displayOrder" INTEGER NOT NULL DEFAULT 0,
    "benefitEligible" BOOLEAN NOT NULL DEFAULT true,
    "emergencyEligible" BOOLEAN NOT NULL DEFAULT true,
    "requiredDocuments" TEXT,
    "maxDependents" INTEGER,
    "pendingAction" TEXT,
    "pendingPayload" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "RelationshipCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PaymentStatus" (
    "id" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "balance" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "monthsPaid" INTEGER NOT NULL DEFAULT 0,
    "totalPaid" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "lastPayment" TIMESTAMP(3),
    "status" "PaymentStatusValue" NOT NULL DEFAULT 'PENDING',
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PaymentStatus_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "InstallmentPlan" (
    "id" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "type" "InstallmentPlanType" NOT NULL,
    "totalAmount" DECIMAL(15,2) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "InstallmentPlan_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Installment" (
    "id" TEXT NOT NULL,
    "planId" TEXT NOT NULL,
    "sequence" INTEGER NOT NULL,
    "amount" DECIMAL(15,2) NOT NULL,
    "dueDate" TIMESTAMP(3) NOT NULL,
    "status" "InstallmentStatus" NOT NULL DEFAULT 'PENDING',
    "paidAt" TIMESTAMP(3),

    CONSTRAINT "Installment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PaymentLog" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "memberId" TEXT,
    "amount" DECIMAL(15,2) NOT NULL,
    "method" TEXT NOT NULL,
    "status" "PaymentLogStatus" NOT NULL DEFAULT 'PENDING',
    "description" TEXT,
    "transactionId" TEXT NOT NULL,
    "receiptUrl" TEXT,
    "signature" TEXT,
    "verificationType" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PaymentLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PaymentIntent" (
    "id" TEXT NOT NULL,
    "transactionId" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "beneficiaryPhone" TEXT,
    "payerPhone" TEXT,
    "amount" DECIMAL(15,2) NOT NULL,
    "breakdown" TEXT,
    "settledAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PaymentIntent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DmsDocument" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'General',
    "tags" TEXT,
    "purpose" TEXT,
    "fileUrl" TEXT NOT NULL,
    "fileName" TEXT NOT NULL,
    "fileType" TEXT NOT NULL DEFAULT 'file',
    "status" "DmsDocStatus" NOT NULL DEFAULT 'PENDING',
    "visibility" TEXT NOT NULL DEFAULT 'staff',
    "pendingAction" TEXT,
    "pendingPayload" JSONB,
    "rejectionReason" TEXT,
    "uploadedById" TEXT,
    "reviewedById" TEXT,
    "approvedById" TEXT,
    "reviewedAt" TIMESTAMP(3),
    "approvedAt" TIMESTAMP(3),
    "archivedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DmsDocument_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ApprovalRequest" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "module" "ApprovalModule" NOT NULL,
    "title" TEXT NOT NULL,
    "summary" TEXT,
    "payload" JSONB NOT NULL,
    "status" "ApprovalStatus" NOT NULL DEFAULT 'PENDING',
    "makerId" TEXT NOT NULL,
    "checkerId" TEXT,
    "targetType" TEXT,
    "targetId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ApprovalRequest_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ApprovalEvent" (
    "id" TEXT NOT NULL,
    "requestId" TEXT NOT NULL,
    "type" "ApprovalEventType" NOT NULL,
    "actorId" TEXT NOT NULL,
    "comment" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ApprovalEvent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EdirSettings" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "monthlyFee" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "registrationFee" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "currency" TEXT NOT NULL DEFAULT 'ETB',
    "dueDay" INTEGER NOT NULL DEFAULT 1,
    "gracePeriodDays" INTEGER NOT NULL DEFAULT 5,
    "nextPaymentDelayDays" INTEGER NOT NULL DEFAULT 0,
    "penaltyTiers" JSONB,
    "dailyPenaltyEnabled" BOOLEAN NOT NULL DEFAULT false,
    "dailyPenaltyType" TEXT NOT NULL DEFAULT 'FIXED',
    "dailyPenaltyValue" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "dailyPenaltyMaxDays" INTEGER NOT NULL DEFAULT 0,
    "autoSuspendMonths" INTEGER NOT NULL DEFAULT 3,
    "autoTerminateMonths" INTEGER NOT NULL DEFAULT 6,
    "minMembershipMonths" INTEGER NOT NULL DEFAULT 0,
    "reinstatementFee" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "autoSuspendEnabled" BOOLEAN NOT NULL DEFAULT true,
    "autoTerminateEnabled" BOOLEAN NOT NULL DEFAULT true,
    "autoReminderEnabled" BOOLEAN NOT NULL DEFAULT true,
    "reminderDaysBefore" JSONB,
    "reminderSentDates" JSONB,
    "memberRoles" JSONB,
    "emergencyReserve" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "operatingFund" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "EdirSettings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RuleChangeLog" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "field" TEXT NOT NULL,
    "previousValue" TEXT,
    "newValue" TEXT,
    "changedById" TEXT,
    "comment" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "RuleChangeLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Bylaw" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "section" TEXT,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "order" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Bylaw_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RulesVersion" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "versionNumber" INTEGER NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "changeSummary" TEXT,
    "effectiveDate" TIMESTAMP(3),
    "status" "RulesVersionStatus" NOT NULL DEFAULT 'DRAFT',
    "authorId" TEXT,
    "approverId" TEXT,
    "approvedAt" TIMESTAMP(3),
    "comment" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "RulesVersion_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RulesAttachment" (
    "id" TEXT NOT NULL,
    "versionId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "RulesAttachment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MemberRequest" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "type" "MemberRequestType" NOT NULL,
    "category" TEXT,
    "subject" TEXT NOT NULL,
    "description" TEXT,
    "payload" JSONB,
    "attachments" JSONB,
    "status" "MemberRequestStatus" NOT NULL DEFAULT 'PENDING',
    "response" TEXT,
    "reviewedById" TEXT,
    "reviewedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MemberRequest_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmergencyType" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "basePayout" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "relationshipPayouts" JSONB,
    "documentationRequired" BOOLEAN NOT NULL DEFAULT false,
    "requiredDocuments" TEXT,
    "requiresApproval" BOOLEAN NOT NULL DEFAULT true,
    "waitingPeriodDays" INTEGER NOT NULL DEFAULT 0,
    "eligibilityMonths" INTEGER NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "EmergencyType_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmergencyClaim" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "typeId" TEXT,
    "affectedPerson" TEXT,
    "description" TEXT,
    "date" TIMESTAMP(3),
    "location" TEXT,
    "priority" TEXT NOT NULL DEFAULT 'normal',
    "status" "EmergencyStatus" NOT NULL DEFAULT 'REPORTED',
    "approvedAmount" DECIMAL(15,2),
    "disbursedAmount" DECIMAL(15,2),
    "disbursementReceipts" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "EmergencyClaim_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmergencyNote" (
    "id" TEXT NOT NULL,
    "claimId" TEXT NOT NULL,
    "note" TEXT,
    "fileUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "EmergencyNote_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Event" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "datetime" TIMESTAMP(3) NOT NULL,
    "location" TEXT,
    "attendanceRequired" BOOLEAN NOT NULL DEFAULT false,
    "absencePenalty" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "status" "EventStatus" NOT NULL DEFAULT 'SCHEDULED',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Event_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EventParticipant" (
    "id" TEXT NOT NULL,
    "eventId" TEXT NOT NULL,
    "memberId" TEXT NOT NULL,
    "status" "ParticipantStatus" NOT NULL DEFAULT 'INVITED',
    "penalized" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "EventParticipant_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AssetCategory" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "AssetCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Asset" (
    "id" TEXT NOT NULL,
    "edirId" TEXT NOT NULL,
    "categoryId" TEXT,
    "name" TEXT NOT NULL,
    "purchaseValue" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "currentValue" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "quantity" INTEGER NOT NULL DEFAULT 1,
    "issuedQuantity" INTEGER NOT NULL DEFAULT 0,
    "condition" TEXT NOT NULL DEFAULT 'good',
    "location" TEXT,
    "status" TEXT NOT NULL DEFAULT 'available',
    "compensationCost" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Asset_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AssetIssuance" (
    "id" TEXT NOT NULL,
    "assetId" TEXT NOT NULL,
    "memberId" TEXT,
    "status" "AssetIssuanceStatus" NOT NULL DEFAULT 'REQUESTED',
    "issuedQty" INTEGER NOT NULL DEFAULT 0,
    "returnedQty" INTEGER NOT NULL DEFAULT 0,
    "condition" TEXT,
    "compensation" DECIMAL(15,2),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AssetIssuance_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Notification" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "edirId" TEXT,
    "type" TEXT NOT NULL,
    "priority" TEXT NOT NULL DEFAULT 'normal',
    "title" TEXT NOT NULL,
    "body" TEXT NOT NULL,
    "linkUrl" TEXT,
    "entityId" TEXT,
    "entityType" TEXT,
    "read" BOOLEAN NOT NULL DEFAULT false,
    "readAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Notification_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL,
    "edirId" TEXT,
    "userId" TEXT,
    "action" TEXT NOT NULL,
    "targetType" TEXT,
    "targetId" TEXT,
    "details" TEXT,
    "archived" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PasswordResetToken" (
    "email" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "expires" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY ("email")
);

-- CreateTable
CREATE TABLE "Setting" (
    "key" TEXT NOT NULL,
    "value" JSONB NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Setting_pkey" PRIMARY KEY ("key")
);

-- CreateTable
CREATE TABLE "EmailLog" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "from" TEXT NOT NULL,
    "to" TEXT NOT NULL,
    "cc" TEXT,
    "subject" TEXT NOT NULL,
    "body" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "triggerEvent" TEXT,
    "relatedEntityId" TEXT,
    "errorMessage" TEXT,
    "messageId" TEXT,

    CONSTRAINT "EmailLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SecurityLog" (
    "id" TEXT NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "actorId" TEXT,
    "event" TEXT NOT NULL,
    "severity" TEXT NOT NULL,
    "ipAddress" TEXT,
    "userAgent" TEXT,
    "details" TEXT NOT NULL,
    "targetId" TEXT,
    "targetType" TEXT,

    CONSTRAINT "SecurityLog_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Edir_branchId_idx" ON "Edir"("branchId");

-- CreateIndex
CREATE UNIQUE INDEX "District_name_key" ON "District"("name");

-- CreateIndex
CREATE UNIQUE INDEX "District_code_key" ON "District"("code");

-- CreateIndex
CREATE UNIQUE INDEX "Branch_code_key" ON "Branch"("code");

-- CreateIndex
CREATE INDEX "Branch_districtId_idx" ON "Branch"("districtId");

-- CreateIndex
CREATE UNIQUE INDEX "Branch_districtId_name_key" ON "Branch"("districtId", "name");

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE UNIQUE INDEX "User_phone_key" ON "User"("phone");

-- CreateIndex
CREATE INDEX "User_roleId_idx" ON "User"("roleId");

-- CreateIndex
CREATE INDEX "User_edirId_idx" ON "User"("edirId");

-- CreateIndex
CREATE INDEX "User_phone_idx" ON "User"("phone");

-- CreateIndex
CREATE INDEX "User_branchId_idx" ON "User"("branchId");

-- CreateIndex
CREATE INDEX "User_districtId_idx" ON "User"("districtId");

-- CreateIndex
CREATE INDEX "Role_edirId_idx" ON "Role"("edirId");

-- CreateIndex
CREATE INDEX "Role_districtId_idx" ON "Role"("districtId");

-- CreateIndex
CREATE INDEX "Role_branchId_idx" ON "Role"("branchId");

-- CreateIndex
CREATE UNIQUE INDEX "Role_edirId_name_key" ON "Role"("edirId", "name");

-- CreateIndex
CREATE INDEX "Member_edirId_idx" ON "Member"("edirId");

-- CreateIndex
CREATE INDEX "Member_userId_idx" ON "Member"("userId");

-- CreateIndex
CREATE INDEX "Member_phone_idx" ON "Member"("phone");

-- CreateIndex
CREATE INDEX "Member_status_idx" ON "Member"("status");

-- CreateIndex
CREATE UNIQUE INDEX "Member_edirId_memberId_key" ON "Member"("edirId", "memberId");

-- CreateIndex
CREATE UNIQUE INDEX "Member_edirId_userId_key" ON "Member"("edirId", "userId");

-- CreateIndex
CREATE INDEX "Relative_memberId_idx" ON "Relative"("memberId");

-- CreateIndex
CREATE INDEX "RelativeDocument_relativeId_idx" ON "RelativeDocument"("relativeId");

-- CreateIndex
CREATE INDEX "RelativeDocument_status_idx" ON "RelativeDocument"("status");

-- CreateIndex
CREATE INDEX "RelativeDocument_supersedesId_idx" ON "RelativeDocument"("supersedesId");

-- CreateIndex
CREATE INDEX "MemberDocument_memberId_idx" ON "MemberDocument"("memberId");

-- CreateIndex
CREATE INDEX "RelationshipCategory_edirId_idx" ON "RelationshipCategory"("edirId");

-- CreateIndex
CREATE UNIQUE INDEX "RelationshipCategory_edirId_name_key" ON "RelationshipCategory"("edirId", "name");

-- CreateIndex
CREATE UNIQUE INDEX "PaymentStatus_memberId_key" ON "PaymentStatus"("memberId");

-- CreateIndex
CREATE INDEX "InstallmentPlan_memberId_idx" ON "InstallmentPlan"("memberId");

-- CreateIndex
CREATE INDEX "Installment_planId_idx" ON "Installment"("planId");

-- CreateIndex
CREATE INDEX "Installment_status_idx" ON "Installment"("status");

-- CreateIndex
CREATE UNIQUE INDEX "Installment_planId_sequence_key" ON "Installment"("planId", "sequence");

-- CreateIndex
CREATE UNIQUE INDEX "PaymentLog_transactionId_key" ON "PaymentLog"("transactionId");

-- CreateIndex
CREATE INDEX "PaymentLog_edirId_idx" ON "PaymentLog"("edirId");

-- CreateIndex
CREATE INDEX "PaymentLog_memberId_idx" ON "PaymentLog"("memberId");

-- CreateIndex
CREATE INDEX "PaymentLog_status_idx" ON "PaymentLog"("status");

-- CreateIndex
CREATE UNIQUE INDEX "PaymentIntent_transactionId_key" ON "PaymentIntent"("transactionId");

-- CreateIndex
CREATE INDEX "PaymentIntent_memberId_idx" ON "PaymentIntent"("memberId");

-- CreateIndex
CREATE INDEX "PaymentIntent_edirId_idx" ON "PaymentIntent"("edirId");

-- CreateIndex
CREATE INDEX "DmsDocument_edirId_idx" ON "DmsDocument"("edirId");

-- CreateIndex
CREATE INDEX "DmsDocument_status_idx" ON "DmsDocument"("status");

-- CreateIndex
CREATE INDEX "DmsDocument_category_idx" ON "DmsDocument"("category");

-- CreateIndex
CREATE INDEX "ApprovalRequest_edirId_idx" ON "ApprovalRequest"("edirId");

-- CreateIndex
CREATE INDEX "ApprovalRequest_module_idx" ON "ApprovalRequest"("module");

-- CreateIndex
CREATE INDEX "ApprovalRequest_status_idx" ON "ApprovalRequest"("status");

-- CreateIndex
CREATE INDEX "ApprovalRequest_makerId_idx" ON "ApprovalRequest"("makerId");

-- CreateIndex
CREATE INDEX "ApprovalEvent_requestId_idx" ON "ApprovalEvent"("requestId");

-- CreateIndex
CREATE UNIQUE INDEX "EdirSettings_edirId_key" ON "EdirSettings"("edirId");

-- CreateIndex
CREATE INDEX "RuleChangeLog_edirId_idx" ON "RuleChangeLog"("edirId");

-- CreateIndex
CREATE INDEX "Bylaw_edirId_idx" ON "Bylaw"("edirId");

-- CreateIndex
CREATE INDEX "RulesVersion_edirId_idx" ON "RulesVersion"("edirId");

-- CreateIndex
CREATE INDEX "RulesVersion_status_idx" ON "RulesVersion"("status");

-- CreateIndex
CREATE INDEX "RulesAttachment_versionId_idx" ON "RulesAttachment"("versionId");

-- CreateIndex
CREATE INDEX "MemberRequest_edirId_idx" ON "MemberRequest"("edirId");

-- CreateIndex
CREATE INDEX "MemberRequest_memberId_idx" ON "MemberRequest"("memberId");

-- CreateIndex
CREATE INDEX "MemberRequest_status_idx" ON "MemberRequest"("status");

-- CreateIndex
CREATE INDEX "EmergencyType_edirId_idx" ON "EmergencyType"("edirId");

-- CreateIndex
CREATE INDEX "EmergencyClaim_edirId_idx" ON "EmergencyClaim"("edirId");

-- CreateIndex
CREATE INDEX "EmergencyClaim_memberId_idx" ON "EmergencyClaim"("memberId");

-- CreateIndex
CREATE INDEX "EmergencyClaim_status_idx" ON "EmergencyClaim"("status");

-- CreateIndex
CREATE INDEX "EmergencyNote_claimId_idx" ON "EmergencyNote"("claimId");

-- CreateIndex
CREATE INDEX "Event_edirId_idx" ON "Event"("edirId");

-- CreateIndex
CREATE INDEX "EventParticipant_eventId_idx" ON "EventParticipant"("eventId");

-- CreateIndex
CREATE UNIQUE INDEX "EventParticipant_eventId_memberId_key" ON "EventParticipant"("eventId", "memberId");

-- CreateIndex
CREATE INDEX "AssetCategory_edirId_idx" ON "AssetCategory"("edirId");

-- CreateIndex
CREATE INDEX "Asset_edirId_idx" ON "Asset"("edirId");

-- CreateIndex
CREATE INDEX "Asset_categoryId_idx" ON "Asset"("categoryId");

-- CreateIndex
CREATE INDEX "AssetIssuance_assetId_idx" ON "AssetIssuance"("assetId");

-- CreateIndex
CREATE INDEX "Notification_userId_read_createdAt_idx" ON "Notification"("userId", "read", "createdAt");

-- CreateIndex
CREATE INDEX "Notification_userId_createdAt_idx" ON "Notification"("userId", "createdAt");

-- CreateIndex
CREATE INDEX "AuditLog_edirId_idx" ON "AuditLog"("edirId");

-- CreateIndex
CREATE INDEX "AuditLog_userId_idx" ON "AuditLog"("userId");

-- CreateIndex
CREATE INDEX "AuditLog_action_idx" ON "AuditLog"("action");

-- CreateIndex
CREATE INDEX "AuditLog_createdAt_idx" ON "AuditLog"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON "PasswordResetToken"("token");

-- CreateIndex
CREATE INDEX "SecurityLog_actorId_idx" ON "SecurityLog"("actorId");

-- CreateIndex
CREATE INDEX "SecurityLog_event_idx" ON "SecurityLog"("event");

-- CreateIndex
CREATE INDEX "SecurityLog_timestamp_idx" ON "SecurityLog"("timestamp");

-- AddForeignKey
ALTER TABLE "Edir" ADD CONSTRAINT "Edir_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES "Branch"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Branch" ADD CONSTRAINT "Branch_districtId_fkey" FOREIGN KEY ("districtId") REFERENCES "District"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "Role"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES "Branch"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_districtId_fkey" FOREIGN KEY ("districtId") REFERENCES "District"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Role" ADD CONSTRAINT "Role_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Role" ADD CONSTRAINT "Role_districtId_fkey" FOREIGN KEY ("districtId") REFERENCES "District"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Role" ADD CONSTRAINT "Role_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES "Branch"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Member" ADD CONSTRAINT "Member_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Member" ADD CONSTRAINT "Member_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Relative" ADD CONSTRAINT "Relative_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RelativeDocument" ADD CONSTRAINT "RelativeDocument_relativeId_fkey" FOREIGN KEY ("relativeId") REFERENCES "Relative"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RelativeDocument" ADD CONSTRAINT "RelativeDocument_supersedesId_fkey" FOREIGN KEY ("supersedesId") REFERENCES "RelativeDocument"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MemberDocument" ADD CONSTRAINT "MemberDocument_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RelationshipCategory" ADD CONSTRAINT "RelationshipCategory_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PaymentStatus" ADD CONSTRAINT "PaymentStatus_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InstallmentPlan" ADD CONSTRAINT "InstallmentPlan_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Installment" ADD CONSTRAINT "Installment_planId_fkey" FOREIGN KEY ("planId") REFERENCES "InstallmentPlan"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PaymentLog" ADD CONSTRAINT "PaymentLog_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PaymentLog" ADD CONSTRAINT "PaymentLog_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApprovalRequest" ADD CONSTRAINT "ApprovalRequest_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApprovalRequest" ADD CONSTRAINT "ApprovalRequest_makerId_fkey" FOREIGN KEY ("makerId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApprovalRequest" ADD CONSTRAINT "ApprovalRequest_checkerId_fkey" FOREIGN KEY ("checkerId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApprovalEvent" ADD CONSTRAINT "ApprovalEvent_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES "ApprovalRequest"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApprovalEvent" ADD CONSTRAINT "ApprovalEvent_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EdirSettings" ADD CONSTRAINT "EdirSettings_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RuleChangeLog" ADD CONSTRAINT "RuleChangeLog_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Bylaw" ADD CONSTRAINT "Bylaw_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RulesVersion" ADD CONSTRAINT "RulesVersion_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RulesVersion" ADD CONSTRAINT "RulesVersion_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RulesVersion" ADD CONSTRAINT "RulesVersion_approverId_fkey" FOREIGN KEY ("approverId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RulesAttachment" ADD CONSTRAINT "RulesAttachment_versionId_fkey" FOREIGN KEY ("versionId") REFERENCES "RulesVersion"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MemberRequest" ADD CONSTRAINT "MemberRequest_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MemberRequest" ADD CONSTRAINT "MemberRequest_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MemberRequest" ADD CONSTRAINT "MemberRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmergencyType" ADD CONSTRAINT "EmergencyType_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmergencyClaim" ADD CONSTRAINT "EmergencyClaim_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmergencyClaim" ADD CONSTRAINT "EmergencyClaim_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmergencyClaim" ADD CONSTRAINT "EmergencyClaim_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES "EmergencyType"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmergencyNote" ADD CONSTRAINT "EmergencyNote_claimId_fkey" FOREIGN KEY ("claimId") REFERENCES "EmergencyClaim"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipant" ADD CONSTRAINT "EventParticipant_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "Event"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EventParticipant" ADD CONSTRAINT "EventParticipant_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AssetCategory" ADD CONSTRAINT "AssetCategory_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Asset" ADD CONSTRAINT "Asset_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Asset" ADD CONSTRAINT "Asset_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "AssetCategory"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AssetIssuance" ADD CONSTRAINT "AssetIssuance_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES "Asset"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AssetIssuance" ADD CONSTRAINT "AssetIssuance_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "Member"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_edirId_fkey" FOREIGN KEY ("edirId") REFERENCES "Edir"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SecurityLog" ADD CONSTRAINT "SecurityLog_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
