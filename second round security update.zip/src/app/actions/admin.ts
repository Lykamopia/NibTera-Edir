'use server';

import { z } from 'zod';
import prisma from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import { getActor, requireActor, assertPermission, assertSameTenant, tenantWhere, resolveEdirId, actorHasPermission, type Actor } from '@/lib/tenant-scope';
import { writeAudit } from '@/lib/audit';
import { logSecurityEvent, SecurityEvent } from '@/lib/security-logger';
import { LogSeverity } from '@/lib/types';
import { ALL_PERMISSION_IDS, PLATFORM_PERMISSION_IDS, filterPermissionsForScope, type RoleScopeKind } from '@/lib/permissions';
import { pickPrimaryMembership } from '@/lib/membership-policy';
import { normalizeEthiopianPhone, isValidEthiopianPhone } from '@/lib/utils';
import { generateTempPassword } from '@/lib/secure-random';
import { issueSetPasswordLink } from '@/lib/set-password-link';
import bcrypt from 'bcrypt';
import { ensureMembershipForUser } from '@/lib/membership-provisioning';
import { ensureDefaultEdirRoles } from '@/lib/default-edir-roles';
import { resubmitRequest, submitForApproval } from '@/lib/approval-engine';
import { revalidatePath } from 'next/cache';
import { failure } from '@/lib/action-result';
import { dateWhere, type DateRangeParam } from '@/lib/date-range';
import { toCsv } from '@/lib/csv';
import { zId, zOptionalId, zName, zEmail, zEthiopianPhone, zOptionalEmail, zOptionalText, zOptionalPhone, zOptionalUploadPath, zOptionalAccountNumber, zCode, zInt, zSearch, zDateRange, parseArgs } from '@/lib/validation';

// ─── Users ───────────────────────────────────────────────────────────────────

export async function getUserLockoutStatus(identifier: string) {
  if (!identifier || typeof identifier !== 'string' || identifier.length > 254) return { isLockedOut: false };
  const id = identifier.trim();
  const user = await prisma.user.findFirst({
    where: id.includes('@') ? { email: id.toLowerCase() } : { phone: normalizeEthiopianPhone(id) },
    select: { lockoutUntil: true },
  });
  if (user?.lockoutUntil && new Date() < user.lockoutUntil) {
    const remainingMinutes = Math.ceil((user.lockoutUntil.getTime() - Date.now()) / 60000);
    return { isLockedOut: true, remainingMinutes };
  }
  return { isLockedOut: false };
}

export async function getUsers() {
  const actor = await getActor();
  await assertPermission(actor, ['view_users', 'manage_users']);
  const users = await prisma.user.findMany({
    where: { ...tenantWhere(actor), NOT: { role: { is: { scope: 'SUPER_ADMIN' } } } }, // hide platform admins
    include: { role: true, edir: true },
    orderBy: { createdAt: 'desc' },
  });
  return users.map(u => ({
    id: u.id, name: u.name, email: u.email, phone: u.phone,
    status: u.status, roleName: u.role?.name ?? null, roleId: u.roleId,
    edirName: u.edir?.name ?? null, edirId: u.edirId,
  }));
}

/** Context for the Users page: whether the actor is a Super-Admin and the Edirs they can target. */
export async function getUserManagementContext() {
  const actor = await getActor();
  await assertPermission(actor, ['view_users', 'manage_users']);
  const edirs = actor.isSuperAdmin
    ? await prisma.edir.findMany({ orderBy: { name: 'asc' }, select: { id: true, name: true } })
    : (actor.edirId ? await prisma.edir.findMany({ where: { id: actor.edirId }, select: { id: true, name: true } }) : []);
  return { isSuperAdmin: actor.isSuperAdmin, edirs };
}

export async function getRoles() {
  const actor = await getActor();
  await assertPermission(actor, ['view_roles', 'manage_roles', 'view_users', 'manage_users']);
  const roles = await prisma.role.findMany({
    where: actor.isSuperAdmin ? {} : { OR: [{ edirId: actor.edirId }, { scope: 'EDIR', edirId: null }] },
    include: { _count: { select: { users: true } }, edir: { select: { name: true } } },
    orderBy: [{ edir: { name: 'asc' } }, { name: 'asc' }],
  });
  return roles.map(r => ({ id: r.id, name: r.name, scope: r.scope, permissions: r.permissions, userCount: r._count.users, edirId: r.edirId, edirName: r.edir?.name ?? null }));
}

/**
 * Create one INVITED user: account → 48h set-password token → set-password email
 * (non-blocking) → audit → best-effort membership. Assumes the caller has already
 * validated and normalized the email (lowercased) and phone (E.164), and that both
 * are unique. Shared by inviteUser (single) and bulkInviteUsers (CSV import).
 */
async function inviteOneUser(
  actor: Actor,
  data: { name: string; email: string; phone: string; roleId: string | null; edirId: string },
): Promise<{ id: string }> {
  const user = await prisma.user.create({
    data: { name: data.name, email: data.email, phone: data.phone, edirId: data.edirId, roleId: data.roleId || null, status: 'INVITED', mustChangePassword: true },
  });
  // Emails a 48h single-use set-password link (best-effort; non-blocking).
  await issueSetPasswordLink({ email: data.email, name: data.name, mode: 'setup' });
  await writeAudit({ edirId: data.edirId, userId: actor.id, action: 'USER_INVITED', targetType: 'User', targetId: user.id, details: `Invited ${data.email}.` });
  // Invited users are also regular Edir members (obligations follow the bylaws, not the role).
  try { await ensureMembershipForUser(user.id); } catch { /* non-fatal */ }
  return user;
}

const inviteSchema = z.object({
  name: zName(),
  email: zEmail,
  phone: zEthiopianPhone,
  roleId: zOptionalId,
  edirId: zOptionalId, // required for Super-Admins; ignored for Edir admins
});

/** Invite a user: validate unique email+phone, create INVITED user, 48h token, email set-password link. */
export async function inviteUser(input: z.infer<typeof inviteSchema>) {
  try {
    const actor = await getActor();
    await assertPermission(actor, 'manage_users');
    const data = inviteSchema.parse(input);
    // Super-Admins must choose which Edir the new user belongs to; Edir admins use their own.
    if (actor.isSuperAdmin && !data.edirId) {
      return { success: false as const, error: 'Select an Edir for the new user.' };
    }
    const edirId = await resolveEdirId(actor, data.edirId);
    if (!isValidEthiopianPhone(data.phone)) return { success: false as const, error: 'Enter a valid Ethiopian phone number.' };
    const phone = normalizeEthiopianPhone(data.phone);
    const email = data.email.toLowerCase().trim();

    const [emailTaken, phoneTaken] = await Promise.all([
      prisma.user.findUnique({ where: { email } }),
      prisma.user.findUnique({ where: { phone } }),
    ]);
    if (emailTaken) return { success: false as const, error: 'A user with this email already exists.' };
    if (phoneTaken) return { success: false as const, error: 'A user with this phone already exists.' };

    if (data.roleId) {
      const role = await prisma.role.findUnique({ where: { id: data.roleId } });
      if (!role) return { success: false as const, error: 'Role not found.' };
      if (role.edirId && role.edirId !== edirId) {
        return { success: false as const, error: 'That role belongs to a different Edir.' };
      }
    }

    const user = await inviteOneUser(actor, { name: data.name, email, phone, roleId: data.roleId || null, edirId });
    revalidatePath('/dashboard/admin/users');
    return { success: true as const, userId: user.id };
  } catch (error) {
    return failure(error);
  }
}

// ─── Bulk user import (CSV) ────────────────────────────────────────────────────

export interface BulkUserRow { name?: string; email?: string; phone?: string; role?: string }
export interface BulkInviteResult {
  success: true;
  total: number;
  created: number;
  failed: { row: number; email?: string; error: string }[];
}

/**
 * Import many users at once into a single target Edir. Each row is validated the
 * same way inviteUser validates (name, unique valid email, unique valid Ethiopian
 * phone, optional role that belongs to the Edir); valid rows are created as
 * INVITED, and a per-row error list is returned for the rest. Row numbers are
 * 1-based (matching the CSV data rows the caller previewed).
 */
export async function bulkInviteUsers(input: { edirId?: string | null; rows: BulkUserRow[] }) {
  try {
    input = z.object({
      edirId: zOptionalId,
      rows: z.array(z.object({ name: z.unknown().optional(), email: z.unknown().optional(), phone: z.unknown().optional(), role: z.unknown().optional() }).passthrough()).max(500, 'Import is limited to 500 rows at a time.'),
    }).parse(input) as typeof input;
    const actor = await getActor();
    await assertPermission(actor, 'manage_users');
    if (actor.isSuperAdmin && !input.edirId) return { success: false as const, error: 'Select an Edir for the imported users.' };
    const edirId = await resolveEdirId(actor, input.edirId);

    const rows = Array.isArray(input.rows) ? input.rows : [];
    if (rows.length === 0) return { success: false as const, error: 'No rows to import.' };
    if (rows.length > 500) return { success: false as const, error: 'Import is limited to 500 rows at a time.' };

    // Roles assignable in this Edir: its own roles + cross-Edir EDIR templates.
    const roles = await prisma.role.findMany({
      where: { OR: [{ edirId }, { scope: 'EDIR', edirId: null }] },
      select: { id: true, name: true },
    });
    const roleByName = new Map(roles.map(r => [r.name.trim().toLowerCase(), r.id]));

    type Norm = { idx: number; name: string; email: string; phone: string; roleId: string | null; error?: string };
    const normalized: Norm[] = rows.map((r, i) => {
      const str = (v: unknown) => (typeof v === 'string' || typeof v === 'number' ? String(v) : '');
      const name = str(r.name).trim();
      const email = str(r.email).toLowerCase().trim();
      const rawPhone = str(r.phone).trim();
      const roleName = str(r.role).trim();
      let error: string | undefined;
      let roleId: string | null = null;
      const nameCheck = zName().safeParse(name);
      if (!nameCheck.success) error = nameCheck.error.issues[0].message;
      else if (!zEmail.safeParse(email).success) error = 'Invalid email.';
      else if (rawPhone.length > 20 || !isValidEthiopianPhone(rawPhone)) error = 'Invalid phone number.';
      else if (roleName.length > 80) error = 'Role name is too long.';
      else if (roleName) {
        const id = roleByName.get(roleName.toLowerCase());
        if (!id) error = `Unknown role "${roleName}".`;
        else roleId = id;
      }
      return { idx: i, name, email, phone: error ? rawPhone : normalizeEthiopianPhone(rawPhone), roleId, error };
    });

    // Existing emails/phones in a single batch (only for rows that parsed cleanly).
    const okRows = normalized.filter(n => !n.error);
    const existing = okRows.length
      ? await prisma.user.findMany({
          where: { OR: [{ email: { in: okRows.map(n => n.email) } }, { phone: { in: okRows.map(n => n.phone) } }] },
          select: { email: true, phone: true },
        })
      : [];
    const takenEmails = new Set(existing.map(u => u.email).filter(Boolean) as string[]);
    const takenPhones = new Set(existing.map(u => u.phone).filter(Boolean) as string[]);

    const failed: { row: number; email?: string; error: string }[] = [];
    const seenEmail = new Set<string>();
    const seenPhone = new Set<string>();
    const toCreate: Norm[] = [];
    for (const n of normalized) {
      const row = n.idx + 1;
      if (n.error) { failed.push({ row, email: n.email || undefined, error: n.error }); continue; }
      if (seenEmail.has(n.email) || seenPhone.has(n.phone)) { failed.push({ row, email: n.email, error: 'Duplicate row in file.' }); continue; }
      if (takenEmails.has(n.email)) { failed.push({ row, email: n.email, error: 'A user with this email already exists.' }); continue; }
      if (takenPhones.has(n.phone)) { failed.push({ row, email: n.email, error: 'A user with this phone already exists.' }); continue; }
      seenEmail.add(n.email); seenPhone.add(n.phone);
      toCreate.push(n);
    }

    let created = 0;
    for (const n of toCreate) {
      try {
        await inviteOneUser(actor, { name: n.name, email: n.email, phone: n.phone, roleId: n.roleId, edirId });
        created++;
      } catch (e) {
        failed.push({ row: n.idx + 1, email: n.email, error: e instanceof Error ? e.message : 'Failed to create.' });
      }
    }

    if (created > 0) revalidatePath('/dashboard/admin/users');
    failed.sort((a, b) => a.row - b.row);
    return { success: true as const, total: rows.length, created, failed };
  } catch (error) {
    return failure(error);
  }
}

/**
 * Account-administration scope check. Edir accounts fall under tenant scoping
 * (assertSameTenant) — so branch/district operators administer the EDIR users of
 * their unit. Platform accounts (no Edir — head-office/district/branch operators)
 * are administered ONLY at head-office level; branch/district users never manage
 * other platform users. Super-Admin-role targets require a full Super-Admin.
 */
async function assertCanAdministerUser(
  actor: Actor,
  user: { edirId: string | null; branchId: string | null; districtId: string | null; roleId?: string | null },
): Promise<void> {
  if (!actor.isSuperAdmin && user.roleId) {
    const role = await prisma.role.findUnique({ where: { id: user.roleId }, select: { scope: true } });
    if (role?.scope === 'SUPER_ADMIN') throw new Error('Platform Super-Admins can only be managed by a Super Administrator.');
  }
  if (user.edirId) {
    await assertSameTenant(actor, user.edirId);
    return;
  }
  if (actor.isSuperAdmin || actor.orgScope === 'HEAD_OFFICE') return;
  throw new Error('Access Denied: platform user accounts are managed at head-office level.');
}

export async function setUserRole(userId: string, roleId: string | null) {
  try {
    [userId, roleId] = parseArgs([zId, zOptionalId], [userId, roleId]) as [string, string | null];
    const actor = await getActor();
    await assertPermission(actor, 'manage_users');
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return { success: false as const, error: 'User not found.' };
    await assertCanAdministerUser(actor, user);
    if (roleId) {
      const role = await prisma.role.findUnique({ where: { id: roleId }, select: { scope: true, edirId: true } });
      if (!role) return { success: false as const, error: 'Role not found.' };
      if (role.scope === 'SUPER_ADMIN') return { success: false as const, error: 'The platform Super-Admin role cannot be assigned here.' };
      if (role.edirId && role.edirId !== user.edirId) return { success: false as const, error: 'That role belongs to a different Edir.' };
    }
    // Rotate the affected user's session on privilege change: bumping tokenVersion
    // invalidates their existing JWT so the new role/permissions take effect on a
    // fresh authenticated session (no stale elevated/!reduced access lingers).
    await prisma.user.update({ where: { id: userId }, data: { roleId, tokenVersion: { increment: 1 } } });
    await writeAudit({ edirId: user.edirId, userId: actor.id, action: 'USER_ROLE_CHANGED', targetType: 'User', targetId: userId });
    await logSecurityEvent({
      event: SecurityEvent.USER_ROLE_CHANGED,
      severity: LogSeverity.WARN,
      actor,
      details: `User '${actor.name}' changed the role of user ${userId} to ${roleId ?? '(none)'}.`,
      targetId: userId, targetType: 'User',
    });
    revalidatePath('/dashboard/admin/users');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

const userAccountSchema = z.object({
  name: zName(),
  email: zEmail,
  phone: zEthiopianPhone,
  roleId: zOptionalId,
  status: z.enum(['ACTIVE', 'INACTIVE', 'SUSPENDED']).optional(),
});

/**
 * Edit a user account's profile + access in one place (Platform Users "Edit"
 * dialog): name, contact, role, and status. Scope follows assertCanAdministerUser
 * (own tenant for Edir accounts; own org unit for platform accounts). Sessions
 * are revoked when the role or status changes.
 */
export async function updateUserAccount(userId: string, input: z.infer<typeof userAccountSchema>) {
  try {
    userId = zId.parse(userId);
    const actor = await getActor();
    await assertPermission(actor, 'manage_users');
    const data = userAccountSchema.parse(input);

    const user = await prisma.user.findUnique({ where: { id: userId }, include: { role: { select: { scope: true } } } });
    if (!user) return { success: false as const, error: 'User not found.' };
    if (user.role?.scope === 'SUPER_ADMIN' && !actor.isSuperAdmin) return { success: false as const, error: 'Platform Super-Admins cannot be edited here.' };
    await assertCanAdministerUser(actor, user);

    if (!isValidEthiopianPhone(data.phone)) return { success: false as const, error: 'Enter a valid Ethiopian phone number.' };
    const phone = normalizeEthiopianPhone(data.phone);
    const email = data.email.toLowerCase().trim();
    const [emailTaken, phoneTaken] = await Promise.all([
      prisma.user.findFirst({ where: { email, id: { not: userId } }, select: { id: true } }),
      prisma.user.findFirst({ where: { phone, id: { not: userId } }, select: { id: true } }),
    ]);
    if (emailTaken) return { success: false as const, error: 'Another user already uses this email.' };
    if (phoneTaken) return { success: false as const, error: 'Another user already uses this phone.' };

    const roleId = data.roleId?.trim() || null;
    if (roleId) {
      const role = await prisma.role.findUnique({ where: { id: roleId }, select: { scope: true, edirId: true, branchId: true, districtId: true } });
      if (!role) return { success: false as const, error: 'Role not found.' };
      if (role.scope === 'SUPER_ADMIN') return { success: false as const, error: 'The platform Super-Admin role cannot be assigned here.' };
      if (user.edirId) {
        if (role.scope !== 'EDIR' || (role.edirId && role.edirId !== user.edirId)) {
          return { success: false as const, error: 'Select a role that belongs to this Edir.' };
        }
      } else if (user.branchId) {
        if (role.scope !== 'BRANCH' || (role.branchId && role.branchId !== user.branchId)) {
          return { success: false as const, error: 'Select a branch-scoped role for a branch user.' };
        }
      } else if (user.districtId) {
        if (role.scope !== 'DISTRICT' || (role.districtId && role.districtId !== user.districtId)) {
          return { success: false as const, error: 'Select a district-scoped role for a district user.' };
        }
      }
    }

    const roleChanged = (user.roleId ?? null) !== roleId;
    const statusChanged = !!data.status && user.status !== data.status;
    await prisma.user.update({
      where: { id: userId },
      data: {
        name: data.name, email, phone, roleId,
        ...(data.status ? { status: data.status } : {}),
        // Privilege/status changes revoke existing sessions.
        ...(roleChanged || statusChanged ? { tokenVersion: { increment: 1 } } : {}),
      },
    });
    // Mirror the new contact details onto the member-directory row (Edir-scoped
    // users are enrolled as members) so the profile doesn't keep showing a stale
    // email/phone that no longer matches the login identity.
    await prisma.member.updateMany({ where: { userId }, data: { name: data.name, email, phone } });

    const parts = [
      roleChanged ? 'role changed' : null,
      statusChanged ? `status → ${data.status}` : null,
    ].filter(Boolean).join('; ');
    await writeAudit({ edirId: user.edirId, userId: actor.id, action: 'USER_ACCOUNT_UPDATED', targetType: 'User', targetId: userId, details: `Updated ${data.name} (${email})${parts ? ` — ${parts}` : ''}.` });
    if (roleChanged) {
      await logSecurityEvent({
        event: SecurityEvent.USER_ROLE_CHANGED,
        severity: LogSeverity.WARN,
        actor,
        details: `User '${actor.name}' changed the role of user ${userId} to ${roleId ?? '(none)'} via account edit.`,
        targetId: userId, targetType: 'User',
      });
    }
    revalidatePath('/dashboard/admin/users');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

export async function setUserStatus(userId: string, status: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED') {
  try {
    [userId, status] = parseArgs([zId, z.enum(['ACTIVE', 'INACTIVE', 'SUSPENDED'])], [userId, status]) as [string, typeof status];
    const actor = await getActor();
    await assertPermission(actor, 'manage_users');
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return { success: false as const, error: 'User not found.' };
    await assertCanAdministerUser(actor, user);
    await prisma.user.update({ where: { id: userId }, data: { status, tokenVersion: { increment: 1 } } });
    await writeAudit({ edirId: user.edirId, userId: actor.id, action: 'USER_STATUS_CHANGED', targetType: 'User', targetId: userId, details: `→ ${status}` });
    revalidatePath('/dashboard/admin/users');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

export async function lockUser(userId: string) { return setUserLock(userId, true); }
export async function unlockUser(userId: string) { return setUserLock(userId, false); }
async function setUserLock(userId: string, lock: boolean) {
  try {
    userId = zId.parse(userId);
    const actor = await getActor();
    await assertPermission(actor, lock ? 'lock_user' : 'unlock_user');
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return { success: false as const, error: 'User not found.' };
    await assertCanAdministerUser(actor, user);
    await prisma.user.update({
      where: { id: userId },
      data: { lockoutUntil: lock ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) : null, failedLoginAttempts: 0 },
    });
    await writeAudit({ edirId: user.edirId, userId: actor.id, action: lock ? 'USER_LOCKED' : 'USER_UNLOCKED', targetType: 'User', targetId: userId });
    revalidatePath('/dashboard/admin/users');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

// NOTE: The former `adminResetUserPassword` (which emailed a reset link but
// hard-failed when no email was on file) was retired in favor of the single
// `adminGenerateTempPassword` reset path, which emails a set-password link,
// activates the account, and prompts for an email when none exists.

/**
 * Recover a user's login WITHOUT exposing a password: the account gets a fresh
 * random hashed password (never returned), is ACTIVATED so they can sign in once
 * they set their own password, existing sessions are revoked, and a single-use
 * set-password link is emailed. If the account has no email, `code: 'NO_EMAIL'`
 * is returned so the UI can collect one (passed via `opts.email` — saved on the
 * account and synced to a linked member profile). Restricted to `reset_password`
 * or an Edir-provisioning permission; org scope applies (assertCanAdministerUser).
 */
export async function adminGenerateTempPassword(userId: string, opts?: { email?: string }) {
  try {
    [userId, opts] = parseArgs([zId, z.object({ email: zOptionalEmail }).optional()], [userId, opts]) as [string, { email?: string } | undefined];
    const actor = await getActor();
    await assertPermission(actor, ['reset_password', 'manage_edirs', 'create_edir', 'register_edir', 'manage_edir_users']);
    const user = await prisma.user.findUnique({ where: { id: userId }, include: { role: { select: { scope: true } } } });
    if (!user) return { success: false as const, error: 'User not found.' };
    if (user.role?.scope === 'SUPER_ADMIN') return { success: false as const, error: 'Platform Super-Admins cannot be reset here.' };
    await assertCanAdministerUser(actor, user);

    const suppliedEmail = opts?.email?.trim().toLowerCase() || null;
    if (suppliedEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(suppliedEmail)) {
      return { success: false as const, error: 'Enter a valid email address.' };
    }
    const email = suppliedEmail ?? user.email ?? null;
    if (!email) return { success: false as const, code: 'NO_EMAIL' as const, error: 'This account has no email on file — add one to send the set-password link.' };
    if (suppliedEmail && suppliedEmail !== user.email) {
      const taken = await prisma.user.findFirst({ where: { email: suppliedEmail, id: { not: userId } }, select: { id: true } });
      if (taken) return { success: false as const, error: 'Another user already uses this email.' };
    }

    const hashedPassword = await bcrypt.hash(generateTempPassword(), 12);
    await prisma.user.update({
      where: { id: userId },
      // Activate (so an INVITED/email-failed manager can sign in), force a change on
      // first login, and rotate the session so any old credential stops working.
      data: {
        hashedPassword, status: 'ACTIVE', mustChangePassword: true, tokenVersion: { increment: 1 }, lockoutUntil: null, failedLoginAttempts: 0,
        ...(suppliedEmail && suppliedEmail !== user.email ? { email: suppliedEmail } : {}),
      },
    });
    if (suppliedEmail && suppliedEmail !== user.email) {
      // Keep a linked member-directory row consistent with the login identity.
      await prisma.member.updateMany({ where: { userId }, data: { email: suppliedEmail } });
    }

    const delivery = await issueSetPasswordLink({ email, name: user.name, mode: 'reset' });
    if (!delivery.sent) {
      return { success: false as const, error: 'The account was reset, but the email could not be sent — check the email settings and try again.' };
    }

    await writeAudit({
      edirId: user.edirId, userId: actor.id, action: 'USER_PASSWORD_RESET', targetType: 'User', targetId: userId,
      details: 'Set-password link emailed (no plaintext credentials issued).',
    });
    await logSecurityEvent({
      event: SecurityEvent.PASSWORD_RESET_SUCCESS,
      severity: LogSeverity.WARN,
      actor,
      details: `User '${actor.name}' emailed a set-password link to user ${userId}.`,
      targetId: userId, targetType: 'User',
    });
    revalidatePath('/dashboard/edirs');
    return { success: true as const, delivery };
  } catch (error) {
    return failure(error);
  }
}

/**
 * 360° profile of a platform/system user account — identity, org placement, role
 * & permissions, account security posture, linked membership, workload, and the
 * account's recent activity trail. Mirrors the member 360 profile for operator
 * accounts. Scope: the caller must be able to administer (or at least see) the
 * account within their org unit.
 */
export async function getPlatformUserProfile(userId: string) {
  userId = zId.parse(userId);
  const actor = await getActor();
  await assertPermission(actor, ['view_users', 'manage_users', 'manage_associations', 'manage_edir_associations', 'manage_edir_users']);
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      role: true,
      edir: { select: { id: true, name: true } },
      branch: { select: { id: true, name: true, code: true, district: { select: { name: true } } } },
      district: { select: { id: true, name: true } },
      members: { include: { paymentStatus: true, edir: { select: { name: true } } }, orderBy: { createdAt: 'asc' } },
    },
  });
  if (!user) return null;
  await assertCanAdministerUser(actor, user);
  const primaryMembership = pickPrimaryMembership(user.members, user.edirId);

  const [approvalsMade, approvalsChecked, pendingSubmitted, activity] = await Promise.all([
    prisma.approvalRequest.count({ where: { makerId: userId } }),
    prisma.approvalRequest.count({ where: { checkerId: userId } }),
    prisma.approvalRequest.count({ where: { makerId: userId, status: 'PENDING' } }),
    prisma.auditLog.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 20, select: { id: true, action: true, details: true, createdAt: true } }),
  ]);

  const placement = user.edir?.name
    ? { kind: 'EDIR' as const, label: `Edir · ${user.edir.name}` }
    : user.branch?.name
      ? { kind: 'BRANCH' as const, label: `Branch · ${user.branch.name}${user.branch.code ? ` (${user.branch.code})` : ''}`, district: user.branch.district?.name ?? null }
      : user.district?.name
        ? { kind: 'DISTRICT' as const, label: `District · ${user.district.name}` }
        : { kind: 'HEAD_OFFICE' as const, label: 'Head Office' };

  return {
    identity: {
      id: user.id, name: user.name, email: user.email, phone: user.phone,
      title: user.title, avatar: user.avatar, createdAt: user.createdAt,
    },
    placement,
    role: user.role
      ? { id: user.role.id, name: user.role.name, scope: user.role.scope, permissions: (user.role.permissions ?? '').split(',').map(p => p.trim()).filter(Boolean) }
      : null,
    security: {
      status: user.status,
      locked: !!(user.lockoutUntil && user.lockoutUntil > new Date()),
      lockoutUntil: user.lockoutUntil,
      failedLoginAttempts: user.failedLoginAttempts,
      lastLoginAt: user.lastLoginAt,
      lastIp: user.lastIp,
      twoFactorEnabled: user.twoFactorEnabled,
      mustChangePassword: user.mustChangePassword,
      onboardingCompleted: user.onboardingCompleted,
      emailVerified: user.emailVerified,
      passwordChangedAt: user.passwordChangedAt,
      passwordResetCount: user.passwordResetCount,
      lastPasswordResetAt: user.lastPasswordResetAt,
    },
    // `membership` stays the primary (home-Edir) one for existing callers;
    // `memberships` lists them all, since the platform membership policy may
    // allow a person to belong to several Edirs.
    membership: primaryMembership
      ? {
          memberId: primaryMembership.id,
          memberCode: primaryMembership.memberId,
          status: primaryMembership.status,
          edirName: primaryMembership.edir?.name ?? null,
          joinDate: primaryMembership.joinDate,
          balance: Number(primaryMembership.paymentStatus?.balance ?? 0),
        }
      : null,
    memberships: user.members.map(m => ({
      memberId: m.id,
      memberCode: m.memberId,
      status: m.status,
      edirId: m.edirId,
      edirName: m.edir?.name ?? null,
      joinDate: m.joinDate,
      balance: Number(m.paymentStatus?.balance ?? 0),
      isPrimary: m.id === primaryMembership?.id,
    })),
    workload: { approvalsMade, approvalsChecked, pendingSubmitted },
    activity,
  };
}

// ─── Roles ───────────────────────────────────────────────────────────────────

const roleSchema = z.object({
  id: zId.optional(),
  name: zName('Role name', 80),
  // Allowlisted again against the permission registry when saved.
  permissions: z.array(z.string().max(64).regex(/^[a-z0-9_]+$/, 'Invalid permission.')).max(500).default([]),
  // Scope is set on create; 'EDIR' (a specific Edir or a cross-Edir template) or
  // 'PLATFORM' (a platform role). Edir Admins always create EDIR roles.
  scope: z.enum(['EDIR', 'PLATFORM']).default('EDIR'),
  edirId: zOptionalId, // EDIR scope: target Edir, or null = template for all Edirs
});

export async function saveRole(input: z.infer<typeof roleSchema>) {
  try {
    const actor = await getActor();
    await assertPermission(actor, 'manage_roles');
    const data = roleSchema.parse(input);

    if (data.id) {
      // ── Editing an existing role ──────────────────────────────────────────
      const existing = await prisma.role.findUnique({ where: { id: data.id } });
      if (!existing) return { success: false as const, error: 'Role not found.' };
      // Non-supers may only edit EDIR roles within their own tenant.
      if (!actor.isSuperAdmin) {
        if (existing.scope !== 'EDIR' || existing.edirId !== actor.edirId) {
          return { success: false as const, error: 'You can only manage roles within your own Edir.' };
        }
      }
      // Validation catalog depends on the role's scope:
      //  • SUPER_ADMIN / PLATFORM → platform catalog (incl. platform-grantable Edir pages)
      //  • EDIR                   → Edir catalog (no platform permissions)
      //  • HEAD_OFFICE / DISTRICT / BRANCH → org roles legitimately mix both
      //    (dashboards + registration approvals + member/payment operations), so
      //    only validate ids and block the super_admin master switch.
      const validIds = new Set(ALL_PERMISSION_IDS as string[]);
      const permissions = (existing.scope === 'SUPER_ADMIN' || existing.scope === 'PLATFORM')
        ? filterPermissionsForScope(data.permissions, 'PLATFORM').join(',')
        : existing.scope === 'EDIR'
          ? filterPermissionsForScope(data.permissions, 'EDIR').join(',')
          : data.permissions.filter(p => validIds.has(p) && p !== 'super_admin').join(',');
      await prisma.role.update({ where: { id: data.id }, data: { name: data.name, permissions } });
      await writeAudit({ edirId: existing.edirId, userId: actor.id, action: 'ROLE_SAVED', targetType: 'Role', targetId: data.id, details: data.name });
      await logSecurityEvent({
        event: SecurityEvent.ROLE_UPDATED,
        severity: LogSeverity.WARN,
        actor,
        details: `User '${actor.name}' updated role '${data.name}' (${data.id}). Permissions: ${permissions || '(none)'}.`,
        targetId: data.id, targetType: 'Role',
      });
      revalidatePath('/dashboard/admin/roles');
      return { success: true as const };
    }

    // ── Creating a new role ─────────────────────────────────────────────────
    const scopeKind: RoleScopeKind = data.scope === 'PLATFORM' ? 'PLATFORM' : 'EDIR';
    if (scopeKind === 'PLATFORM' && !actor.isSuperAdmin) {
      return { success: false as const, error: 'Only Super Administrators can create platform roles.' };
    }

    let scope: 'EDIR' | 'PLATFORM';
    let edirId: string | null;
    if (scopeKind === 'PLATFORM') {
      scope = 'PLATFORM';
      edirId = null;
    } else {
      scope = 'EDIR';
      if (actor.isSuperAdmin) {
        edirId = data.edirId ?? null; // specific Edir, or null = cross-Edir template
        if (edirId) {
          const edir = await prisma.edir.findUnique({ where: { id: edirId }, select: { id: true } });
          if (!edir) return { success: false as const, error: 'Edir not found.' };
        }
      } else {
        if (!actor.edirId) return { success: false as const, error: 'Your account is not assigned to an Edir.' };
        edirId = actor.edirId; // forced to own Edir
      }
    }

    const permissions = filterPermissionsForScope(data.permissions, scopeKind).join(',');
    const created = await prisma.role.create({ data: { name: data.name, permissions, scope, edirId } });
    await writeAudit({ edirId, userId: actor.id, action: 'ROLE_SAVED', targetType: 'Role', targetId: null, details: data.name });
    await logSecurityEvent({
      event: SecurityEvent.ROLE_CREATED,
      severity: LogSeverity.WARN,
      actor,
      details: `User '${actor.name}' created ${scope} role '${data.name}' (${created.id}). Permissions: ${permissions || '(none)'}.`,
      targetId: created.id, targetType: 'Role',
    });
    revalidatePath('/dashboard/admin/roles');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

export async function deleteRole(id: string) {
  try {
    id = zId.parse(id);
    const actor = await getActor();
    await assertPermission(actor, 'manage_roles');
    const role = await prisma.role.findUnique({ where: { id }, include: { _count: { select: { users: true } } } });
    if (!role) return { success: false as const, error: 'Role not found.' };
    // Platform/org roles are managed at head-office (Super-Admin) level only —
    // mirrors saveRole: non-supers may only touch EDIR roles of their own tenant.
    if (!actor.isSuperAdmin) {
      if (role.scope !== 'EDIR' || role.edirId !== actor.edirId) {
        return { success: false as const, error: 'You can only manage roles within your own Edir.' };
      }
    }
    if (role._count.users > 0) return { success: false as const, error: 'Cannot delete a role still assigned to users.' };
    await prisma.role.delete({ where: { id } });
    await writeAudit({ edirId: role.edirId, userId: actor.id, action: 'ROLE_DELETED', targetType: 'Role', targetId: id, details: role.name });
    await logSecurityEvent({
      event: SecurityEvent.ROLE_DELETED,
      severity: LogSeverity.WARN,
      actor,
      details: `User '${actor.name}' deleted role '${role.name}' (${id}).`,
      targetId: id, targetType: 'Role',
    });
    revalidatePath('/dashboard/admin/roles');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

// ─── Edirs (Super Admin) ─────────────────────────────────────────────────────

export async function getEdirs(range?: DateRangeParam) {
  const actor = await getActor();
  await assertPermission(actor, ['view_edir', 'register_edir', 'approve_edir_registration', 'approve_edir_update', 'manage_edirs', 'create_edir', 'edit_edir', 'revoke_edir', 'delete_edir', 'view_edir_reports', 'super_admin']);
  // Org scope: Branch/District users only see Edirs within their unit (mirrors
  // getEdirRegistrations); Head Office / Super-Admin see all.
  const where: Prisma.EdirWhereInput = { ...dateWhere('createdAt', range) };
  if (actor.orgScope === 'BRANCH' && actor.branchId) where.branchId = actor.branchId;
  else if (actor.orgScope === 'DISTRICT' && actor.districtId) where.branch = { districtId: actor.districtId };

  const edirs = await prisma.edir.findMany({
    where,
    include: {
      _count: { select: { members: true, users: true } },
      branch: { select: { id: true, name: true, code: true, district: { select: { name: true } } } },
    },
    orderBy: { name: 'asc' },
  });
  return edirs.map(e => ({
    id: e.id,
    name: e.name,
    description: e.description,
    status: e.status,
    // Full registration profile — kept in sync with the Register Edir form.
    accountNumber: e.accountNumber,
    address: e.address,
    branchId: e.branchId,
    branchName: e.branch?.name ?? null,
    branchCode: e.branch?.code ?? null,
    districtName: e.branch?.district?.name ?? null,
    contactPersonName: e.contactPersonName,
    contactAddress: e.contactAddress,
    contactMobile: e.contactMobile,
    contactEmail: e.contactEmail,
    agreementDocUrl: e.agreementDocUrl,
    createdAt: e.createdAt,
    members: e._count.members,
    users: e._count.users,
  }));
}

/** The current actor's Edir-management capabilities, for gating UI actions. */
export async function getEdirAdminCapabilities() {
  const actor = await getActor();
  return {
    canCreate: actorHasPermission(actor, ['create_edir', 'manage_edirs', 'super_admin']),
    canEdit: actorHasPermission(actor, ['edit_edir', 'manage_edirs', 'super_admin']),
    canRevoke: actorHasPermission(actor, ['revoke_edir', 'manage_edirs', 'super_admin']),
    canDelete: actorHasPermission(actor, ['delete_edir', 'manage_edirs', 'super_admin']),
    canApprove: actorHasPermission(actor, ['approve_edir_registration', 'approve_edir_update', 'super_admin']),
  };
}

export interface SaveEdirInput {
  id?: string;
  name: string;
  description?: string | null;
  accountNumber?: string | null;
  address?: string | null;
  branchId?: string | null;
  contactPersonName?: string | null;
  contactAddress?: string | null;
  contactMobile?: string | null;
  contactEmail?: string | null;
  agreementDocUrl?: string | null;
}

export async function saveEdir(input: SaveEdirInput) {
  try {
    input = z.object({
      id: zId.optional(),
      name: zName('Edir name', 160),
      description: zOptionalText('Description', { max: 2000, multiline: true }),
      accountNumber: zOptionalAccountNumber,
      address: zOptionalText('Address', { max: 300 }),
      branchId: zOptionalId,
      contactPersonName: zOptionalText('Contact person', { max: 120 }),
      contactAddress: zOptionalText('Contact address', { max: 300 }),
      contactMobile: zOptionalPhone,
      contactEmail: zOptionalEmail,
      agreementDocUrl: zOptionalUploadPath,
    }).parse(input) as SaveEdirInput;
    const actor = await getActor();
    // Granular: editing requires edit_edir, creating requires create_edir (manage_edirs/super_admin are the umbrella).
    await assertPermission(actor, input.id ? ['edit_edir', 'manage_edirs', 'super_admin'] : ['create_edir', 'manage_edirs', 'super_admin']);
    const name = input.name?.trim();
    if (!name) return { success: false as const, error: 'Name is required.' };

    // Full registration profile — mirrors the Register Edir form so the directory
    // edit and the registration form stay in sync.
    const norm = (v?: string | null) => (v?.trim() ? v.trim() : null);
    const profile = {
      description: norm(input.description),
      accountNumber: norm(input.accountNumber),
      address: norm(input.address),
      branchId: norm(input.branchId),
      contactPersonName: norm(input.contactPersonName),
      contactAddress: norm(input.contactAddress),
      contactMobile: norm(input.contactMobile),
      contactEmail: norm(input.contactEmail),
      agreementDocUrl: norm(input.agreementDocUrl),
    };

    if (input.id) {
      // A RETURNED registration being revised by its original maker resubmits the
      // registration (that Edir isn't live yet) — this path always applies directly.
      const returned = await prisma.approvalRequest.findFirst({
        where: { module: 'EDIR_REGISTRATION', targetId: input.id, status: 'RETURNED' },
        orderBy: { createdAt: 'desc' },
        select: { id: true, makerId: true },
      });
      const resubmittingReturned = !!returned && returned.makerId === actor.id;

      // Editing a LIVE Edir's information is sensitive, so anyone below head office
      // (branch/district/edir makers) routes the change through the EDIR_UPDATE
      // maker–checker workflow instead of applying it directly. Head office and
      // super admins (the checkers / top authority) apply immediately.
      const mustApprove = !actor.isSuperAdmin && actor.orgScope !== 'HEAD_OFFICE' && !resubmittingReturned;

      if (mustApprove) {
        const current = await prisma.edir.findUnique({ where: { id: input.id } });
        if (!current) return { success: false as const, error: 'Edir not found.' };
        // Only fields the EDIR_UPDATE executor is allowed to apply (branch
        // reassignment is a head-office action, deliberately excluded).
        const editable: Record<string, any> = { name, ...profile };
        delete editable.branchId;
        const changes: Record<string, any> = {};
        for (const [k, v] of Object.entries(editable)) {
          if ((current as any)[k] !== v) changes[k] = v;
        }
        if (Object.keys(changes).length === 0) return { success: true as const, message: 'No changes to submit.' };

        const pending = await prisma.approvalRequest.findFirst({
          where: { module: 'EDIR_UPDATE', targetId: input.id, status: { in: ['PENDING', 'RETURNED'] } },
          select: { id: true },
        });
        if (pending) return { success: false as const, error: 'This Edir already has a pending update awaiting approval.' };

        await submitForApproval(actor, {
          edirId: input.id,
          module: 'EDIR_UPDATE',
          title: `Edir update: ${name}`,
          summary: `${Object.keys(changes).length} field(s) changed`,
          payload: { edirId: input.id, changes },
          targetType: 'Edir',
          targetId: input.id,
        });
        await writeAudit({ edirId: input.id, userId: actor.id, action: 'EDIR_UPDATE_SUBMITTED', targetType: 'Edir', targetId: input.id, details: `Update submitted for approval: ${Object.keys(changes).join(', ')}.` });
        revalidatePath('/dashboard/edir-registration');
        revalidatePath('/dashboard/approvals');
        return { success: true as const, pendingApproval: true, message: 'Edir update submitted for approval.' };
      }

      await prisma.edir.update({ where: { id: input.id }, data: { name, ...profile } });
      // If this Edir's registration was RETURNED to its maker, saving the revision
      // re-submits it to the checker (status → PENDING) so it reappears in the
      // approval queue. Only the original maker's edit resubmits (engine enforces this).
      if (resubmittingReturned) {
        await resubmitRequest(returned!.id);
      }
    } else {
      const edir = await prisma.edir.create({ data: { name, ...profile } });
      await prisma.edirSettings.create({ data: { edirId: edir.id } });
      await ensureDefaultEdirRoles(edir.id); // so the Edir can be staffed & configured immediately
    }
    await writeAudit({ userId: actor.id, action: 'EDIR_SAVED', targetType: 'Edir', targetId: input.id ?? null, details: name });
    revalidatePath('/dashboard/edir-registration');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

/** Revoke (deactivate) or restore an Edir without deleting it. */
export async function revokeEdir(edirId: string, status: 'ACTIVE' | 'SUSPENDED' | 'CLOSED') {
  try {
    [edirId, status] = parseArgs([zId, z.enum(['ACTIVE', 'SUSPENDED', 'CLOSED'])], [edirId, status]) as [string, typeof status];
    const actor = await getActor();
    await assertPermission(actor, ['revoke_edir', 'manage_edirs', 'super_admin']);
    const edir = await prisma.edir.findUnique({ where: { id: edirId }, select: { id: true, name: true, status: true } });
    if (!edir) return { success: false as const, error: 'Edir not found.' };
    await prisma.edir.update({ where: { id: edirId }, data: { status } });
    await writeAudit({
      edirId, userId: actor.id, action: status === 'ACTIVE' ? 'EDIR_REACTIVATED' : 'EDIR_REVOKED',
      targetType: 'Edir', targetId: edirId, details: `${edir.name}: ${edir.status} → ${status}`,
    });
    revalidatePath('/dashboard/edir-registration');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

/** Permanently delete an Edir — only when it has no operational data. */
export async function deleteEdir(edirId: string) {
  try {
    edirId = zId.parse(edirId);
    const actor = await getActor();
    await assertPermission(actor, ['delete_edir', 'manage_edirs', 'super_admin']);
    const edir = await prisma.edir.findUnique({ where: { id: edirId }, select: { id: true, name: true } });
    if (!edir) return { success: false as const, error: 'Edir not found.' };

    // Guard: refuse if any operational data exists.
    const [members, payments, approvals, emergencies, events, assets, requests, bylaws, rules, users] = await Promise.all([
      prisma.member.count({ where: { edirId } }),
      prisma.paymentLog.count({ where: { edirId } }),
      prisma.approvalRequest.count({ where: { edirId } }),
      prisma.emergencyClaim.count({ where: { edirId } }),
      prisma.event.count({ where: { edirId } }),
      prisma.asset.count({ where: { edirId } }),
      prisma.memberRequest.count({ where: { edirId } }),
      prisma.bylaw.count({ where: { edirId } }),
      prisma.rulesVersion.count({ where: { edirId } }),
      prisma.user.count({ where: { edirId } }),
    ]);
    const blockers: string[] = [];
    if (members) blockers.push(`${members} member(s)`);
    if (users) blockers.push(`${users} user(s)`);
    if (payments) blockers.push(`${payments} payment(s)`);
    if (approvals) blockers.push(`${approvals} approval(s)`);
    if (emergencies) blockers.push(`${emergencies} emergency claim(s)`);
    if (events) blockers.push(`${events} event(s)`);
    if (assets) blockers.push(`${assets} asset(s)`);
    if (requests) blockers.push(`${requests} member request(s)`);
    if (bylaws || rules) blockers.push('rules/bylaws');
    if (blockers.length) {
      return { success: false as const, error: `Cannot delete — this Edir has operational data: ${blockers.join(', ')}. Revoke it instead.` };
    }

    // Only auto-provisioned roles + settings remain; remove them, then the Edir.
    await prisma.$transaction(async (tx) => {
      await tx.role.deleteMany({ where: { edirId } });
      await tx.edirSettings.deleteMany({ where: { edirId } });
      await tx.edir.delete({ where: { id: edirId } });
    });
    await writeAudit({ userId: actor.id, action: 'EDIR_DELETED', targetType: 'Edir', targetId: edirId, details: edir.name });
    revalidatePath('/dashboard/edir-registration');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

// ─── Logs (read) ─────────────────────────────────────────────────────────────

export async function getSecurityLogs(page = 1, limit = 20) {
  [page, limit] = parseArgs([zInt('Page', 1, 100_000), zInt('Limit', 1, 100)], [page, limit]) as [number, number];
  const actor = await getActor();
  await assertPermission(actor, ['view_audit_log', 'manage_audit_log']);
  const [items, total] = await Promise.all([
    prisma.securityLog.findMany({ orderBy: { timestamp: 'desc' }, skip: (page - 1) * limit, take: limit }),
    prisma.securityLog.count(),
  ]);
  return { items, total, pages: Math.ceil(total / limit) };
}

const auditFilterSchema = z.object({
  page: zInt('Page', 1, 100_000).optional(),
  action: z.preprocess(v => (v === '' ? null : v), z.string().trim().max(64).regex(/^[A-Z0-9_]+$/i, 'Invalid action filter.').nullable().optional()),
  query: zSearch,
  archived: z.boolean().optional(),
  range: zDateRange,
});

function auditWhere(actor: Actor, rawParams: { action?: string; query?: string; archived?: boolean; range?: DateRangeParam }): Prisma.AuditLogWhereInput {
  const params = auditFilterSchema.parse(rawParams);
  return {
    ...tenantWhere(actor),
    ...dateWhere('createdAt', params.range),
    archived: params.archived ?? false,
    ...(params.action ? { action: { contains: params.action } } : {}),
    ...(params.query ? { details: { contains: params.query, mode: 'insensitive' } } : {}),
  };
}

export async function getAuditLogs(params: { page?: number; action?: string; query?: string; archived?: boolean; range?: DateRangeParam } = {}) {
  params = auditFilterSchema.parse(params) as typeof params;
  const actor = await getActor();
  await assertPermission(actor, ['view_audit_log', 'manage_audit_log']);
  const page = Math.max(1, params.page ?? 1);
  const limit = 25;
  const where = auditWhere(actor, params);
  const [items, total] = await Promise.all([
    prisma.auditLog.findMany({ where, include: { user: true }, orderBy: { createdAt: 'desc' }, skip: (page - 1) * limit, take: limit }),
    prisma.auditLog.count({ where }),
  ]);
  return { items: items.map(a => ({ ...a, userName: a.user?.name ?? a.user?.email ?? 'System' })), total, page, pages: Math.ceil(total / limit) };
}

export async function archiveAuditLog(id: string) {
  try {
    id = zId.parse(id);
    const { actor, edirId } = await requireActor('manage_audit_log');
    const log = await prisma.auditLog.findUnique({ where: { id } });
    if (!log) return { success: false as const, error: 'Audit entry not found.' };
    if (log.edirId) await assertSameTenant(actor, log.edirId);
    await prisma.auditLog.update({ where: { id }, data: { archived: true } });
    await writeAudit({ edirId, userId: actor.id, action: 'AUDIT_ENTRY_ARCHIVED', targetType: 'AuditLog', targetId: id });
    revalidatePath('/dashboard/audit');
    return { success: true as const };
  } catch (error) {
    return failure(error);
  }
}

export async function exportAuditCsv(params: { action?: string; query?: string; archived?: boolean; range?: DateRangeParam } = {}) {
  const actor = await getActor();
  await assertPermission(actor, ['view_audit_log', 'manage_audit_log']);
  const logs = await prisma.auditLog.findMany({ where: auditWhere(actor, params), include: { user: true }, orderBy: { createdAt: 'desc' }, take: 5000 });
  const header = ['Timestamp', 'Action', 'User', 'Target Type', 'Target ID', 'Details'];
  const rows = logs.map(a => [
    a.createdAt.toISOString(), a.action, a.user?.name ?? a.user?.email ?? 'System',
    a.targetType ?? '', a.targetId ?? '', a.details ?? '',
  ]);
  return toCsv([header, ...rows]);
}
