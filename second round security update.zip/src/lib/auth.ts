
import { PrismaAdapter } from "@next-auth/prisma-adapter";
import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import prisma from "@/lib/prisma";
import bcrypt from "bcrypt";
import { headers } from 'next/headers';
import { LogSeverity } from './types';
import { logSecurityEvent, SecurityEvent } from './security-logger';
import { sendConcurrentLoginNotification } from './email';
import { normalizeNibEmail, normalizeEthiopianPhone } from './utils';
import { newCsrfSessionId } from './csrf-token';
import { SESSION_COOKIE_NAME } from './session-cookie';
import { SESSION_IDLE_TIMEOUT_MS, createUserSession, revokeAllUserSessions, revokeSession, validateSession } from './sessions';

const MAX_FAILED_ATTEMPTS = parseInt(process.env.MAX_FAILED_LOGIN_ATTEMPTS || '5', 10);
const LOCKOUT_DURATION_MINUTES = parseInt(process.env.LOCKOUT_DURATION_MINUTES || '15', 10);

type OrgScope = 'HEAD_OFFICE' | 'DISTRICT' | 'BRANCH' | 'EDIR';

function deriveOrgScope(edirId: string | null, branchId: string | null, districtId: string | null, isSuperAdmin: boolean): OrgScope {
  if (isSuperAdmin || (!edirId && !branchId && !districtId)) return 'HEAD_OFFICE';
  if (districtId && !branchId) return 'DISTRICT';
  if (branchId && !edirId) return 'BRANCH';
  return 'EDIR';
}

/**
 * Handles a failed login attempt: increments the counter and locks the account
 * once the threshold is reached.
 */
async function handleFailedAttempt(dbUser: { id: string; failedLoginAttempts: number }) {
  const newFailedAttempts = (dbUser.failedLoginAttempts || 0) + 1;
  const updates: any = { failedLoginAttempts: newFailedAttempts };

  if (newFailedAttempts >= MAX_FAILED_ATTEMPTS) {
    updates.lockoutUntil = new Date(Date.now() + LOCKOUT_DURATION_MINUTES * 60 * 1000);
  }

  await prisma.user.update({ where: { id: dbUser.id }, data: updates });

  if (newFailedAttempts >= MAX_FAILED_ATTEMPTS) {
    throw new Error(`Account locked due to too many failed attempts. Please try again in ${LOCKOUT_DURATION_MINUTES} minutes.`);
  }
}

/** Extracts and cleans an IP address from proxy headers. */
function getCleanIp(raw: string | null | undefined): string {
  if (!raw || raw === 'unknown') return 'unknown';
  let ip = raw.split(',')[0].trim();
  const colonCount = (ip.match(/:/g) || []).length;
  if (colonCount === 1) return ip.split(':')[0];
  if (ip.startsWith('[') && ip.includes(']:')) return ip.split(']:')[0].replace('[', '');
  if (ip.includes('.') && ip.includes(':')) {
    const parts = ip.split(':');
    const lastPart = parts[parts.length - 1];
    if (/^\d+$/.test(lastPart) && parts.length > 1) {
      return parts.slice(0, -1).join(':').replace(/^.*:/, '');
    }
    return ip.replace(/^.*:/, '');
  }
  return ip;
}

/**
 * Look up a user by phone OR email. An identifier containing "@" is treated as
 * an email; otherwise it is normalized as an Ethiopian phone number.
 */
async function findUserByIdentifier(identifier: string) {
  const id = identifier.trim();
  if (id.includes('@')) {
    return prisma.user.findUnique({ where: { email: normalizeNibEmail(id) }, include: { role: true } });
  }
  const phone = normalizeEthiopianPhone(id);
  return prisma.user.findUnique({ where: { phone }, include: { role: true } });
}

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        identifier: { label: "Phone or Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const identifier = (credentials as any)?.identifier || (credentials as any)?.email;
        if (!identifier || !credentials?.password) {
          throw new Error("Invalid credentials");
        }

        try {
          const user = await findUserByIdentifier(identifier);
          if (!user) throw new Error("Invalid username or password");

          if (user.lockoutUntil && new Date() < new Date(user.lockoutUntil)) {
            const remainingMinutes = Math.ceil((new Date(user.lockoutUntil).getTime() - Date.now()) / (60 * 1000));
            throw new Error(`Account locked. Please try again in ${remainingMinutes} minutes.`);
          }

          if (user.status === 'TERMINATED') {
            // Termination blocks the login entirely (portal and mini-app session).
            throw new Error("Your membership has been terminated and this account can no longer sign in. Please contact your Edir administrator.");
          }
          if (user.status !== 'ACTIVE') {
            throw new Error("Your account is not active. Please contact an administrator or complete your invitation.");
          }

          if (!user.hashedPassword) {
            throw new Error("No password set for this account. Please use your invitation link to set a password.");
          }

          const isPasswordValid = await bcrypt.compare(credentials.password, user.hashedPassword);
          if (!isPasswordValid) {
            await handleFailedAttempt(user);
            throw new Error("Invalid username or password");
          }

          if (user.failedLoginAttempts > 0) {
            await prisma.user.update({ where: { id: user.id }, data: { failedLoginAttempts: 0, lockoutUntil: null } });
          }

          const headerList = await headers();
          const rawIp = headerList.get('x-forwarded-for') || headerList.get('cf-connecting-ip') || 'unknown';
          const ipAddress = getCleanIp(rawIp);
          const userAgent = headerList.get('user-agent') || 'unknown';

          const isDifferentDevice = user.lastIp && user.lastUserAgent && (user.lastIp !== ipAddress || user.lastUserAgent !== userAgent);
          const wasRecentlyActive = user.updatedAt && (Date.now() - new Date(user.updatedAt).getTime() < 60 * 60 * 1000);

          if (user.lastLoginAt && isDifferentDevice && wasRecentlyActive) {
            await logSecurityEvent({
              event: SecurityEvent.CONCURRENT_LOGIN_ATTEMPT,
              severity: LogSeverity.WARN,
              actor: { id: user.id, name: user.name || user.email },
              details: `Concurrent login detected for ${user.email || user.phone}. IP: ${ipAddress}`,
              targetId: user.id,
              targetType: 'User',
            });
            if (user.email) {
              sendConcurrentLoginNotification({ to: user.email, name: user.name || user.email, ipAddress, userAgent })
                .catch(err => console.error("Failed to send concurrent login notification:", err));
            }
            (user as any).isConcurrentLogin = true;
            (user as any).concurrentDetails = { ip: ipAddress, userAgent, timestamp: new Date().toISOString() };
          }

          await logSecurityEvent({
            event: SecurityEvent.LOGIN_SUCCESS,
            severity: LogSeverity.INFO,
            actor: { id: user.id, name: user.name || user.email },
            details: `User ${user.email || user.phone} logged in successfully.`,
          });

          (user as any).hashedPassword = null;
          return user;
        } catch (error: any) {
          const passthrough = ["Account locked", "not active", "Invalid username or password", "No password set"];
          if (passthrough.some(msg => error.message?.includes(msg))) throw error;
          console.error('Auth Error:', error.message);
          throw new Error("Authentication failed. Please check your credentials.");
        }
      },
    }),
  ],
  cookies: (() => {
    const nextAuthUrl = (process.env.NEXTAUTH_URL || '').trim();
    const usesHttps = nextAuthUrl.toLowerCase().startsWith('https://');
    const namePrefix = usesHttps ? '__Secure-' : '';
    return {
      // SameSite=Strict means the session cookie is never attached to a request
      // originating from another site, so a cross-site forgery of a
      // state-changing action arrives unauthenticated. This is the first line of
      // defence; the per-request CSRF token in src/lib/csrf.ts is the second.
      sessionToken: {
        name: SESSION_COOKIE_NAME,
        options: { httpOnly: true, sameSite: 'strict', path: '/', secure: usesHttps },
      },
      // NextAuth's own sign-in CSRF cookie. Every flow that uses it (credentials
      // sign-in) is same-origin, so Strict costs nothing and blocks cross-site
      // priming of the login form. '__Host-' pins it to this exact origin.
      csrfToken: {
        name: `${usesHttps ? '__Host-' : ''}next-auth.csrf-token`,
        options: { httpOnly: true, sameSite: 'strict', path: '/', secure: usesHttps },
      },
      // Lax (not Strict) so a top-level navigation back from an external link
      // still resolves the post-login destination.
      callbackUrl: {
        name: `${namePrefix}next-auth.callback-url`,
        options: { sameSite: 'lax', path: '/', secure: usesHttps },
      },
    };
  })(),
  // Timeouts are enforced server-side on the UserSession row (src/lib/sessions.ts):
  // 30 min idle, 8 h absolute. The JWT's own maxAge mirrors the idle timeout so
  // an abandoned cookie also dies on its own; updateAge rolls it on activity.
  session: { strategy: "jwt", maxAge: SESSION_IDLE_TIMEOUT_MS / 1000, updateAge: 5 * 60 },
  pages: { signIn: "/login" },
  events: {
    // Logout invalidates the server side, not just the browser cookie: EVERY
    // session of the user is revoked and tokenVersion is bumped, so the token
    // being signed out — and any copy of it, or any other concurrent session —
    // is dead from this moment on.
    async signOut({ token }) {
      if (typeof token?.sid !== 'string' || typeof token?.id !== 'string') return;
      const revoked = await revokeAllUserSessions(token.id, 'logout');
      if (revoked > 0) {
        await logSecurityEvent({
          event: SecurityEvent.LOGOUT,
          severity: LogSeverity.INFO,
          actor: { id: token.id as string, name: token.name ?? null },
          details: `User ${token.name ?? token.id} signed out (session ${token.sid}).`,
          targetId: token.id as string,
          targetType: 'User',
        });
      }
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
  callbacks: {
    async jwt({ token, user, trigger, session }) {
      const headerList = await headers();
      const rawIp = headerList.get('x-forwarded-for') || headerList.get('cf-connecting-ip') || 'unknown';
      const ipAddress = getCleanIp(rawIp);
      const userAgent = headerList.get('user-agent');

      // Absolute session lifetime cap (8h): regardless of activity, a session
      // cannot live past this. Returning {} invalidates the JWT and forces re-login.
      if (token.absoluteExpiry && Date.now() > Number(token.absoluteExpiry)) {
        return {};
      }

      if (trigger === "update" && session?.onboardingCompleted === true) {
        token.onboardingCompleted = true;
      }

      // CSRF session binding (see src/lib/csrf-token.ts). A fresh secret is
      // minted on every sign-in and rotated whenever the session is updated
      // (e.g. after the first-login password change), which invalidates every
      // CSRF token issued before the change. Sessions created before this
      // binding existed get one on their next refresh.
      if (user || trigger === "update" || (token.id && !token.csrfSid)) {
        token.csrfSid = newCsrfSessionId();
      }

      if (user) { // Initial sign-in
        const dbUser = await prisma.user.findUnique({ where: { id: user.id }, include: { role: true } });
        if (dbUser) {
          // Each sign-in gets its own server-side session; createUserSession
          // revokes the user's other sessions (one active session per user),
          // so re-authenticating elsewhere logs the previous browser out.
          await prisma.user.update({
            where: { id: dbUser.id },
            data: { lastIp: ipAddress, lastUserAgent: userAgent, lastLoginAt: new Date() },
          });
          const serverSession = await createUserSession({
            userId: dbUser.id,
            tokenVersion: dbUser.tokenVersion,
            ipAddress,
            userAgent,
          });
          token.sid = serverSession.id;
          token.absoluteExpiry = serverSession.expiresAt.getTime();
          token.tokenVersion = dbUser.tokenVersion;
          token.onboardingCompleted = dbUser.onboardingCompleted;
          token.mustChangePassword = dbUser.mustChangePassword;
          token.edirId = dbUser.edirId;
          token.branchId = dbUser.branchId;
          token.districtId = dbUser.districtId;
          const perms = (dbUser.role?.permissions ?? '').split(',').map(p => p.trim()).filter(Boolean);
          token.permissions = perms;
          token.isSuperAdmin = perms.includes('super_admin');
          token.orgScope = deriveOrgScope(dbUser.edirId, dbUser.branchId, dbUser.districtId, token.isSuperAdmin);
        }
        token.id = user.id;
        token.ip = ipAddress;
        token.userAgent = userAgent;
        if ((user as any).isConcurrentLogin) {
          token.showConcurrentAlert = true;
          token.concurrentDetails = (user as any).concurrentDetails;
        }
      }

      if (token.ip && ipAddress && ipAddress !== 'unknown' && token.ip !== 'unknown' && token.ip !== ipAddress) {
        await logSecurityEvent({
          event: SecurityEvent.SESSION_HIJACK_ATTEMPT,
          severity: LogSeverity.CRITICAL,
          actor: { id: token.id as string, name: token.name },
          details: `Session IP mismatch for ${token.name}. Token IP: ${token.ip}, Request IP: ${ipAddress}.`,
        });
        // Kill the session server-side too, so the token is dead everywhere.
        if (typeof token.sid === 'string') await revokeSession(token.sid, 'ip_mismatch');
        return {};
      }

      if (token.userAgent && userAgent && token.userAgent !== userAgent) {
        await logSecurityEvent({
          event: SecurityEvent.USER_AGENT_MISMATCH,
          severity: LogSeverity.CRITICAL,
          actor: { id: token.id as string, name: token.name },
          details: `User-Agent changed for ${token.name}.`,
        });
        if (typeof token.sid === 'string') await revokeSession(token.sid, 'user_agent_mismatch');
        return {};
      }

      if (token.id) {
        if (typeof token.tokenVersion !== 'number') return {};
        const dbUser = await prisma.user.findUnique({
          where: { id: token.id as string },
          select: { tokenVersion: true, onboardingCompleted: true, mustChangePassword: true, edirId: true, branchId: true, districtId: true, role: { select: { permissions: true, scope: true } } },
        });
        if (!dbUser || dbUser.tokenVersion !== token.tokenVersion) {
          if (typeof token.sid === 'string') await revokeSession(token.sid, 'invalidated');
          return {};
        }
        // The server-side session record is authoritative: revoked, idle,
        // expired or unknown (e.g. a token issued before sessions were tracked)
        // → the token is dead, whatever its own expiry says.
        const check = await validateSession(token.sid, token.id as string, dbUser.tokenVersion);
        if (!check.valid) return {};
        token.onboardingCompleted = dbUser.onboardingCompleted;
        token.mustChangePassword = dbUser.mustChangePassword;
        token.edirId = dbUser.edirId;
        token.branchId = dbUser.branchId;
        token.districtId = dbUser.districtId;
        const perms = (dbUser.role?.permissions ?? '').split(',').map(p => p.trim()).filter(Boolean);
        token.permissions = perms;
        // Full access requires the `super_admin` master switch (not merely the scope).
        token.isSuperAdmin = perms.includes('super_admin');
        // Derive organizational scope from user's branch/district/edir assignment.
        token.orgScope = deriveOrgScope(dbUser.edirId, dbUser.branchId, dbUser.districtId, token.isSuperAdmin);
      }

      return token;
    },
    async session({ session, token }) {
      // The jwt callback returns {} for a revoked/idle/expired session. Report
      // that as "no session" (an empty object is treated as signed-out by both
      // getServerSession and useSession) instead of a user with empty fields.
      if (!token?.id) return {} as any;
      if (token) {
        session.user.id = token.id as string;
        session.user.name = token.name;
        session.user.email = token.email;
        session.user.image = token.picture;
        (session.user as any).onboardingCompleted = token.onboardingCompleted;
        (session.user as any).mustChangePassword = token.mustChangePassword;
        (session.user as any).edirId = token.edirId;
        (session.user as any).branchId = token.branchId;
        (session.user as any).districtId = token.districtId;
        (session.user as any).orgScope = token.orgScope;
        (session.user as any).showConcurrentAlert = token.showConcurrentAlert;
        (session.user as any).concurrentDetails = token.concurrentDetails;
      }
      return session;
    },
  },
};
